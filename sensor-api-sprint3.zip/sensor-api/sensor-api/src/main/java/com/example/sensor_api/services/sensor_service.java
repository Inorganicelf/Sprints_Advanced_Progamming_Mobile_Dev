package com.example.sensor_api.services;

import com.example.sensor_api.models.sensor_model;
import com.example.sensor_api.repository.sensor_repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class sensor_service {

    @Autowired
    private sensor_repository repository;

    @Transactional
    public sensor_model create(sensor_model sensorData) {
        // Procura por um sensor existente com o mesmo nome para evitar duplicatas.
        Optional<sensor_model> existingSensorOpt = repository.findByName(sensorData.getName());

        if (existingSensorOpt.isPresent()) {
            // Se o sensor já existe, atualiza os seus dados com a nova leitura.
            sensor_model sensorToUpdate = existingSensorOpt.get();
            sensorToUpdate.setCurrentValue(sensorData.getCurrentValue());
            sensorToUpdate.setUnit(sensorData.getUnit());
            sensorToUpdate.setStatus(sensorData.getStatus());
            sensorToUpdate.setType(sensorData.getType());
            sensorToUpdate.setLocation(sensorData.getLocation());
            return repository.save(sensorToUpdate);
        } else {
            // Se o sensor não for encontrado, salva a nova entidade.
            return repository.save(sensorData);
        }
    }

    public void delete(long id) {
        repository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public sensor_model getByID(long id) {
        return repository.findById(id).orElse(null);
    }

    @Transactional(readOnly = true)
    public List<sensor_model> getAll() {
        return repository.findAll();
    }

    @Transactional
    public sensor_model update(sensor_model sensor) {
        // Busca o sensor pelo ID. O ideal seria tratar o caso de não encontrar.
        sensor_model new_sensor = repository.findById(sensor.getId()).orElse(null);
        if (new_sensor != null) {
            new_sensor.setName(sensor.getName());
            new_sensor.setCurrentValue(sensor.getCurrentValue());
            new_sensor.setUnit(sensor.getUnit());
            new_sensor.setStatus(sensor.getStatus());
            new_sensor.setType(sensor.getType());
            new_sensor.setLocation(sensor.getLocation());
            return repository.save(new_sensor);
        }
        // Em um cenário real, seria bom lançar uma exceção aqui.
        return null;
    }
}