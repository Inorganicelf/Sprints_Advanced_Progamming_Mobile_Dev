package com.example.sensor_api.repository;

import com.example.sensor_api.models.sensor_model;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface sensor_repository extends JpaRepository<sensor_model, Long> {
    /**
     * Método para encontrar um sensor pelo nome.
     * É utilizado para verificar se um sensor já existe antes de tentar criar um novo,
     * permitindo a atualização de um registro existente (lógica de "upsert").
     * @param name O nome do sensor a ser buscado.
     * @return Um Optional contendo o sensor se encontrado, ou vazio caso contrário.
     */
    Optional<sensor_model> findByName(String name);
}